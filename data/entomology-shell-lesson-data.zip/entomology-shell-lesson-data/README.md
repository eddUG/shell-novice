# Entomology Shell Lesson Data

This dataset accompanies a shell workshop tailored for entomologists.
It includes realistic-but-synthetic files for practicing navigation,
searching, pipes/filters, loops, and scripting.

## Structure
- trap_data/ : CSV files with trap counts from multiple sites and dates
- sequences/ : Small FASTQ files (toy reads) for QC and filtering practice
- images/    : Placeholder specimen images (JPG) to practice globbing and batch ops
- field_notes/: Plain-text notes from field teams
- metadata/  : Reference tables for sites and specimen IDs
- scripts/   : Simple Bash scripts used in exercises
- docs/      : A short lesson guide

All data are synthetic and safe to share.

Generated: 2025-09-08
