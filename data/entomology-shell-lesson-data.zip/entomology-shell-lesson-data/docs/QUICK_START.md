# Quick Start (Entomology Shell Practice)

Try these commands from the dataset root:

- Show where you are:
  pwd

- List top-level folders:
  ls

- Peek at trap data:
  head -n 5 trap_data/mosquitoes_2025.csv

- Count *Anopheles* rows:
  grep "Anopheles" trap_data/mosquitoes_2025.csv | wc -l

- Unique species:
  cut -d',' -f4 trap_data/mosquitoes_2025.csv | sort | uniq

- Summarize counts by species (all CSVs):
  ./scripts/summarize_trap_counts.sh

- Find FASTQ files collected on 2025-06-02:
  ls sequences/*2025-06-02*

- Search field notes for 'power outage':
  grep -Ri "power outage" field_notes
