#!/usr/bin/env bash
# Count how many rows in trap CSVs match a given species (case-sensitive exact match).
# Usage: ./count_species.sh "Anopheles gambiae"
grep -h "$1" trap_data/*.csv | wc -l
