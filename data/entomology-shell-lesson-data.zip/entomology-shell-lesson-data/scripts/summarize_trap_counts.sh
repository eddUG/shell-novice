#!/usr/bin/env bash
# Summarize total counts per species across trap_data CSVs.
# Usage: ./summarize_trap_counts.sh
awk -F',' 'NR>1 {counts[$4]+=$5} END {for (sp in counts) print counts[sp]","sp}' trap_data/*.csv | sort -n
