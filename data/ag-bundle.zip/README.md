# AG1000G Toy Bundle (for Unix Shell Capstone)

Files:
- variants_subset.vcf.gz  (VCF v4.2, 120 toy variants across 2L/2R/3L/3R/X; FORMAT/GT only)
- samples.tsv             (sample_id, species, population, country, latitude, longitude)
- regions.bed             (chrom, start, end, name)

Generated: 2025-10-04
